 <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
	
	<!--LIVEDEMO_00 -->

	
	  
	  <script async="" src="js/gtm.js"></script><script type="text/javascript" async="" src="js/ga.js"></script>
	  <script src="js/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script>